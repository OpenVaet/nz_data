CSV and geojson files for locations of interest from the August 2021 comunity cluster

Locations have been machine geocoded. If the location does not match the address the address is correct.
